import 'package:get/get.dart';

class AvatarInfoController extends GetxController {


}
