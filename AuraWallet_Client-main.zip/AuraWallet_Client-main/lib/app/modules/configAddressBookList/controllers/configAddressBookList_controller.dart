import 'package:get/get.dart';

class ConfigAddressBookListController extends GetxController {


}
