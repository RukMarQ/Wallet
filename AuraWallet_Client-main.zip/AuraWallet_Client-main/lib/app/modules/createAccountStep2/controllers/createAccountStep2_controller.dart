import 'dart:io';
import 'package:dio/dio.dart';
import 'package:get/get.dart';

class CreateAccountStep2Controller extends GetxController {




}
