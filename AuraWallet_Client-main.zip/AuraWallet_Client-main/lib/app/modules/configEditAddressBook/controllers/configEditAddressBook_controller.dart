import 'package:get/get.dart';

class ConfigEditAddressBookController extends GetxController {




}
